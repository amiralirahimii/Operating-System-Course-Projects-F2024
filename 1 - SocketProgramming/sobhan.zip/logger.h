#ifndef LOGGER_H
#define LOGGER_H

#define RD_WR 0666

void creating_log_file(char* name);
void log_msg(char* name, char* msg);


#endif